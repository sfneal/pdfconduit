from setuptools import setup, find_packages

long_description = """
GUI wrapper for pdf.
"""

setup(
    name='pdfconduit-gui',
    install_requires=[
        'PyPDF3>=0.0.6',
        'pdfrw',
        'PyMuPDF',
        'Pillow',
        'PySimpleGUI>=2.9.0',
        'reportlab',
        'looptools',
        'pdfconduit',
    ],
    version='0.1.1.3',
    packages=find_packages(),
    namespace_packages=['pdf'],
    include_package_data=True,
    url='https://github.com/mrstephenneal/pdf',
    license='',
    author='Stephen Neal',
    author_email='stephen@stephenneal.net',
    description='PDF toolkit for preparing documents for distribution.',
    long_description=long_description,
)
