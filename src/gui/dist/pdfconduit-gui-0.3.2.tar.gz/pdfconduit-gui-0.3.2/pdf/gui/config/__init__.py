from pdf.gui.config import images


__all__ = ['images']
