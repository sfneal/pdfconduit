from pdf.api.routes import app


__all__ = ['app']
