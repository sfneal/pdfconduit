from pdf.modify.rotate import rotate
from pdf.modify.upscale import upscale
from pdf.modify.slice import slicer


__all__ = ['rotate', 'upscale', 'slicer']
